/*

Rhianne Hadfied
10084038
*/
#ifndef WINDOW_H    
#define WINDOW_H

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>




static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void mouseButton (GLFWwindow *window, int button, int action, int mods);
bool saveObjFile();
bool subDivTrue();
GLFWwindow* setupWindow();

#endif
